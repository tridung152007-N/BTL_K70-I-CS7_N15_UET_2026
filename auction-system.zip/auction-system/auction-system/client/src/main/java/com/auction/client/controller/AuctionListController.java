package com.auction.client.controller;

import com.auction.client.network.SocketClient;
import com.auction.client.service.AuctionClientService;
import com.auction.client.session.UserSession;
import com.auction.common.network.Message;
import com.auction.common.network.MessageType;
import com.auction.common.util.JsonUtil;
import com.auction.server.model.Auction;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.List;

public class AuctionListController {

    @FXML private TableView<Auction> auctionTable;
    @FXML private TableColumn<Auction, String> nameCol;
    @FXML private TableColumn<Auction, String> priceCol;
    @FXML private TableColumn<Auction, String> endCol;
    @FXML private TableColumn<Auction, String> stateCol;

    private final AuctionClientService service = new AuctionClientService();
    private String currentUserId;

    @FXML
    public void initialize() {
        currentUserId = UserSession.getInstance().getUserId();

        // Cấu hình các cột
        nameCol.setCellValueFactory(c -> {
            Auction auction = c.getValue();
            String name = auction.getItemName();
            if (name == null || name.isEmpty()) {
                name = auction.getItemId();
            }
            return new SimpleStringProperty(name);
        });

        priceCol.setCellValueFactory(c ->
                new SimpleStringProperty(String.format("%,.0f VNĐ", c.getValue().getCurrentPrice())));

        endCol.setCellValueFactory(c ->
                new SimpleStringProperty(c.getValue().getEndTime() != null
                        ? c.getValue().getEndTime().toString() : ""));

        stateCol.setCellValueFactory(c ->
                new SimpleStringProperty(c.getValue().getState().name()));

        // ================= DOUBLE CLICK =================
        auctionTable.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                Auction selectedAuction = auctionTable.getSelectionModel().getSelectedItem();
                if (selectedAuction != null) {
                    goToBidRoom(selectedAuction);
                }
            }
        });

        // Đăng ký listener và load dữ liệu
        SocketClient.getInstance().addListener(this::onMessage);
        handleRefresh();
    }

    @FXML
    public void handleRefresh() {
        if (currentUserId != null) {
            service.requestAuctionList(currentUserId);
        }
    }

    private void onMessage(Message msg) {
        if (msg.getType() == MessageType.AUCTION_LIST) {
            try {
                Auction[] auctions = JsonUtil.fromJson(msg.getPayload(), Auction[].class);
                List<Auction> list = Arrays.asList(auctions);

                Platform.runLater(() -> {
                    auctionTable.setItems(FXCollections.observableArrayList(list));
                });
            } catch (Exception e) {
                System.err.println("Lỗi parse danh sách auction: " + e.getMessage());
            }
        }
    }

    private void goToBidRoom(Auction auction) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/auction/client/fxml/BidRoom.fxml"));

            Stage stage = (Stage) auctionTable.getScene().getWindow();
            Scene scene = new Scene(loader.load(), 900, 650);

            BidRoomController ctrl = loader.getController();

            // Truyền tên thật của item
            ctrl.setAuction(auction.getId(), auction.getItemName() != null ? auction.getItemName() : auction.getItemId());
            ctrl.setCurrentUserId(currentUserId);

            stage.setScene(scene);
            stage.setTitle("Phòng đấu giá – " + (auction.getItemName() != null ? auction.getItemName() : auction.getItemId()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}