package com.auction.client.controller;

import com.auction.client.chart.BidHistoryChart;
import com.auction.client.network.SocketClient;
import com.auction.client.service.AuctionClientService;
import com.auction.client.service.AutoBidClientService;
import com.auction.common.network.Message;
import com.auction.common.network.MessageType;
import com.auction.common.util.JsonUtil;
import com.auction.server.model.BidTransaction;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class BidRoomController {

    @FXML private Label itemNameLabel;
    @FXML private Label currentPriceLabel;
    @FXML private Label timerLabel;
    @FXML private TextField bidAmountField;
    @FXML private TextField maxBidField;
    @FXML private TextField incrementField;
    @FXML private StackPane chartContainer;

    private final AuctionClientService auctionService = new AuctionClientService();
    private final AutoBidClientService autoBidService = new AutoBidClientService();
    private final BidHistoryChart bidHistoryChart = new BidHistoryChart();

    private String auctionId;
    private String currentUserId;
    private String itemName;

    @FXML
    public void initialize() {
        chartContainer.getChildren().add(bidHistoryChart.getChart());
        SocketClient.getInstance().addListener(this::onMessage);

        // Set lại tên nếu đã có dữ liệu từ setAuction
        if (itemName != null && itemNameLabel != null) {
            itemNameLabel.setText(itemName);
        }
    }

    @FXML
    public void handleBid() {
        try {
            String text = bidAmountField.getText().trim();
            if (text.isEmpty()) {
                showAlert("Lỗi", "Vui lòng nhập số tiền muốn đấu giá.");
                return;
            }

            double amount = Double.parseDouble(text);

            if (amount <= 0) {
                showAlert("Lỗi", "Số tiền phải lớn hơn 0.");
                return;
            }

            auctionService.placeBid(auctionId, currentUserId, amount);
            bidAmountField.clear();

            // Thông báo thành công (tạm thời)
            showAlert("Thành công", "Đã đặt giá " + String.format("%,.0f VNĐ", amount));

        } catch (NumberFormatException e) {
            showAlert("Lỗi", "Vui lòng nhập số tiền hợp lệ (chỉ dùng số).");
        } catch (Exception e) {
            showAlert("Lỗi", "Không thể đặt giá: " + e.getMessage());
        }
    }

    @FXML
    public void handleAutoBid() {
        try {
            double maxBid    = Double.parseDouble(maxBidField.getText().trim());
            double increment = Double.parseDouble(incrementField.getText().trim());

            if (maxBid <= 0 || increment <= 0) {
                showAlert("Lỗi", "Giá tối đa và bước giá phải lớn hơn 0.");
                return;
            }

            autoBidService.registerAutoBid(auctionId, currentUserId, maxBid, increment);
            showAlert("Thành công", "Đã đăng ký Auto Bid!");

        } catch (NumberFormatException e) {
            showAlert("Lỗi", "Vui lòng nhập số hợp lệ cho Auto Bid.");
        }
    }

    private void showAlert(String title, String content) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(content);
            alert.showAndWait();
        });
    }
    @FXML
    public void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/auction/client/fxml/AuctionList.fxml"));

            Stage stage = (Stage) itemNameLabel.getScene().getWindow();
            Scene scene = new Scene(loader.load(), 900, 600);

            stage.setScene(scene);
            stage.setTitle("Danh sách đấu giá");

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Lỗi", "Không thể quay lại: " + e.getMessage());
        }
    }

    private void onMessage(Message msg) {
        Platform.runLater(() -> {
            switch (msg.getType()) {
                case BID_UPDATE -> {
                    BidTransaction bid = JsonUtil.fromJson(msg.getPayload(), BidTransaction.class);
                    currentPriceLabel.setText(String.format("%,.0f VNĐ", bid.getAmount()));
                    bidHistoryChart.addBidPoint(bid);
                }
                case AUCTION_END -> {
                    timerLabel.setText("✅ Phiên đã kết thúc!");
                    bidAmountField.setDisable(true);   // Khóa không cho bid nữa
                }
                case ERROR -> {
                    String err = JsonUtil.fromJson(msg.getPayload(), ErrorPayload.class).error();
                    showAlert("Lỗi từ Server", err);
                }
            }
        });
    }

    public void setAuction(String auctionId, String itemName) {
        this.auctionId = auctionId;
        this.itemName = (itemName != null && !itemName.isEmpty()) ? itemName : "Phiên #" + auctionId;

        // Cập nhật label an toàn
        if (itemNameLabel != null) {
            itemNameLabel.setText(this.itemName);
        } else {
            // Nếu label chưa inject, lưu lại và set sau trong initialize
            this.itemName = itemName;
        }
    }

    public void setCurrentUserId(String userId) {
        this.currentUserId = userId;
    }

    // Helper class để parse error
    private record ErrorPayload(String error) {}
}